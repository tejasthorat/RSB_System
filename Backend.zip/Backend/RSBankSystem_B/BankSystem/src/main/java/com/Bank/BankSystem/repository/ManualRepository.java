package com.Bank.BankSystem.repository;

public class ManualRepository {
}
