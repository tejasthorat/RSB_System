package com.Bank.BankSystem.controller;

public class ManualController {
}
