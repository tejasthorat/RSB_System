package com.Bank.BankSystem.service;

public class ManualService {
}
