package com.Bank.BankSystem.entity;

public class Manual {
}
